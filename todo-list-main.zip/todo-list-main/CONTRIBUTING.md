# Beitrag zur ToDo-List App 🚀

Vielen Dank, dass Sie daran interessiert sind, zur Weiterentwicklung unserer ToDo-List-App beizutragen! 🌟 Beiträge aus der Community sind uns sehr willkommen, um unsere App zu verbessern.

## Erste Schritte 🏁

1. **GitHub-Konto erstellen:**
   - Stellen Sie sicher, dass Sie über ein [GitHub-Konto](https://github.com/signup) verfügen und angemeldet sind.

2. **Repository Klonen:**
   - Klonen Sie das Repository in Ihr eigenes GitHub-Konto.

3. **Lokales Repository klonen:**
   - Klonen Sie das Gabel-Repository auf Ihre lokale Maschine.

   ```bash
   git clone https://github.com/your-username/todolist-app.git
   cd todolist-app
